import java.util.Scanner;
import java.io.*;
import javax.swing.*;
import java.awt.*;

public class adminActionCenter
{

	public static void actionCenter(String userID)
	{
		
	}
	
}