import java.util.Scanner;
import java.io.*;
import javax.swing.*;
import java.awt.*;


public class loginFunction
{
	
	//---------------------------------LOGIN SCREEN----------------------------------------	
	public static void loginScreen()
	{
		
		int choice;
		String userID;
		String userPassword;
		
	
		JPanel login = new JPanel();

		login.setLayout(new BoxLayout(login, BoxLayout.Y_AXIS));
		
		final JTextField usernameField = new JTextField(5);
		JTextField passwordField = new JTextField(5);
		
		login.add(new JLabel("Please enter your login information:"));
		login.add(Box.createVerticalStrut(15));
		
		login.add(new JLabel("User ID:"));
		login.add(usernameField);
		login.add(Box.createVerticalStrut(15));
		
		login.add(new JLabel("Password:"));
		login.add(passwordField);
		login.add(Box.createVerticalStrut(15));
		
		
		UIManager.put("OptionPane.cancelButtonText", "Exit");
		UIManager.put("OptionPane.okButtonText", "Submit");
		
		choice = JOptionPane.showConfirmDialog(null, login, "Electronic Assignment and Attendance Guide", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		
		//User chooses to exit program.
		if(choice == JOptionPane.CANCEL_OPTION || choice == JOptionPane.CLOSED_OPTION)
		{
			System.exit(1);
		}
		
		else if(choice == JOptionPane.OK_OPTION)
		{
			userID = usernameField.getText();
			userPassword = passwordField.getText();
			
			//User has submitted their userID and password.
			confirmCredentials.credentials(userID, userPassword);
		}
	
	}
	
}