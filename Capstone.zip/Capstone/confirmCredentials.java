import java.util.Scanner;
import java.io.*;
import javax.swing.*;
import java.awt.*;

public class confirmCredentials
{
	
		public static void credentials(String ID, String Pass)
		{
		
		String currentID = ID;
		String userPass = Pass;
		String userType;
		

		//THIS IS WHERE WE WILL CHECK WITH THE DATABASE TO CONFIRM THE USER'S CREDENTIALS.
		//For now, we will use these placeholder logins.
		if (currentID == "admin")
		{
			userType = "admin";
						System.out.println(ID);
												System.out.println(currentID);
																		System.out.println(currentID);
																								System.out.println(currentID);
		}
		else if (currentID == "teacher")
		{
			userType = "teacher";
		}
		else
		{
			userType = "student";
		}			
		
		//If the credentials match up, the user is taken to their respective action center.
		if (userType == "admin")
		{
			adminActionCenter.actionCenter(userID);
		}
	
		if (userType == "teacher")
		{
			teacherActionCenter.actionCenter(userID);
		}
		
		if (userType == "student")
		{
			studentActionCenter.actionCenter(userID);
		}
		
	}

	
}