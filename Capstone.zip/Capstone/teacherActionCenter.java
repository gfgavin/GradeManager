import java.util.Scanner;
import java.io.*;
import javax.swing.*;
import java.awt.*;

public class teacherActionCenter
{

	public static void actionCenter(String userID)
	{
	
	}
	
}